﻿function handleSubmit(event) {
    event.preventDefault();

    alert("Thanks for your query!");
    window.history.back();

    return false;
}
