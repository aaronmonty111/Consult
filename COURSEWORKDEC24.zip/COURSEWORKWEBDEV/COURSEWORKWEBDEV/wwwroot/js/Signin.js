﻿
function
    validateLogin(event) {
    
    
    const username = document.querySelector('input[name="uname"]').value;
    const password = document.querySelector('input[name="psw"]').value;
    
    const correctUsername = "hello@gmail.com";
    const correctPassword = "hello"; 
    if (username === correctUsername && password === correctPassword) 
        alert("Successfully logged in!");
       
        window.history.back();
    

    } else { alert("Email or password is incorrect."); }
}
