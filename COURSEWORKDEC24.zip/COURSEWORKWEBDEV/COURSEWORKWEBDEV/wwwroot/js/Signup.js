﻿function validateSignup(event) {


    const email = document.querySelector('input[name="email"]').value;
    const password = document.querySelector('input[name="psw"]').value;
    const passwordRepeat = document.querySelector('input[name="psw-repeat"]').value;
   

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const test = emailRegex.test(email);

    if (!test) {
        alert("Please enter a valid email address.");
        return false;
    }

    

    
    if (password !== passwordRepeat) {
        alert("Passwords do not match.");
        return false;
    }
  
    if (password == passwordRepeat && test) {
        alert("Sign up successful!");

      
        return true;
    } 

    console.log("Validation Errored");
    return false
}