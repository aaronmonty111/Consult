﻿namespace COURSEWORKWEBDEV.Models
{
    public class AboutUs
    {
    }
}
